## AI-Engine Integration

📌 **Overview**

This integration adds types required by AI-Engine to UAgents.

UAgentResponse digest:
```
model:66841ea279697fd62a029c37b7297e4097966361407a2cc49cd1e7defb924685
```